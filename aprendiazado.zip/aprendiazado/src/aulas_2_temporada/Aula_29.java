package aulas_2_temporada;

public class Aula_29 {

    //Pré e Pós Incremento e Decremento




    public static void main(String[] args) {


        int a = 2;

        //Pré incremento
        a++;

        //Pós incremento
        ++a;

        //Pré decremento
        a--;

        //Pós decremento
        --a;

        int b = 5;
        int c = ++b; //pré incremento

        System.out.println(b); // as linhas de incrementam adicionam valor
        System.out.println(c);

        System.out.println("______________________________");

        int d = 5;
        int e = d++; //pós incremento
        System.out.println(d);
        System.out.println(e);

        //função c/ nome = autoexplicativo



    }

}
