package aulas_1_temporada;

public class Aula_08_a_09 {

    public static void main(String[] args){

    // PALVRAS RESERVADA ou PALAVRAS CHAVES
    //São palavras de cada linguagem reservadas para ações e modificações no codigo


    //QUEBRA DE LINHA

    // printnl = as informações são imprimidas em linha diferentes
    // print = imprime as informações em uma mesma linha

    // \n = Quebra de linha dentro do codigo

    //EX:
        System.out.println("Eu amo o \n BRASIL" );

        //Declaração de mais de uma variavel:

        //Jeito 1
        double n1;
        double n2;

        //Jeito 2
        double N1,N2;

        //Ordem de procedência das operações matemáticas:
        // "()" ==>  "*/"  ==> "+-"


    }
}
