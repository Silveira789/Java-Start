package aulas_1_temporada;

public class Aula_01_a_07 {


    //Inicio_ Onde ocorre a leitura inicial do meu código (ponto de inicio)
    public static void main(String[] args) {
        //METODO PRINCIPAL
        //MAIN = principal
        //args = argumentos

        //Duas formas de escrever uma variável e atribuir um valor á ela
        //1°
        int X;
        X = 7;
        //2°
        int Y = 43;
        //Exemplo de operação matemática simples:
        int res = Y / X;
        System.out.println(res);
        //Demonstrar 2 valores:
        System.out.println( X +" "+ Y );

        String texto2 = "wtf?";
        String texto = new String("Como assim?");
        System.out.println(texto);
        System.out.println(texto2);


        

        /*

        Variáveis numéricas
        * Em operações matematicas, o resultado de uma operação irá retornar do mesmo tipo de variáveis
            Ex: Se "X" for int e "Y" for int o resultado vai retornar int, independente se "res" é float ou double
        *No Brasil numeros decimais são utlilizados com " , " Em demais paises(americanos) usa-se " . "

        */
        //-----------------------------------------------------------------------------------------------------------

        //DADOS PRIMITIVOS  

        //Armazenamento de valores inteiros
        byte a;
        short b;
        int c;
        long d;
        //Armazenamento de valores decimais
        float e;
        double f;
        //Valores booleanos: V e F
        boolean g;
        //Um unico caractere: letra, numero, ponto de interrogação...etc
        char h;

        // String não são dados primitivos mas são variaveis importantes

        //-----------------------------------------------------------------------------------------------------------

    }




//Fim
}
