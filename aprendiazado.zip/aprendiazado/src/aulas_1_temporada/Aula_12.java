package aulas_1_temporada;

public class Aula_12 {
    //Conteudo: "Casting"
    // Significa forçar um determindado valor ou variável a ser um determinado tipo de data

    public static void main(String[] args) {

        int x = 10;
        int y = 6; int z = 3;
        double a = 2.7; double b = 1.1;
        double c = (double)x/z;


        System.out.println(" x = " + x);
        System.out.println(" y = " + y);
        System.out.println(" z = " + z);

        System.out.println(" c = " + c);
        



    }

}
