package aulas_1_temporada;

public class Aula_22 {

    //Aula de LAÇOS/CICLOS/LOOPS --> WHILE
    // WHILE (ENQUANTO) = Enquanto a condição for V repetir a instrução;

    public static void main(String[] args) {

        float temploop = 1;

        while (temploop < 2)  {
            temploop += 0.1;
            System.out.println(temploop);

        }

    }


}
