package aulas_1_temporada;

public class Aula_16 {

    // conteudo: Atalhos de operadores

    public static void main(String[] args) {

        //Variádas formas para a mesma operação;

        int x = 10;
        x = x + 4;/*  =  */ x += 4;

        int y = 1;
        y = y + 1; /*  =  */ y += 1; /*  =  */ y ++;

    }


}
